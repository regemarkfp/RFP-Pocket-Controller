# RFP Pocket Control

Android app to control and paint a Blackmagic Pocket Cinema Camera 4K over Bluetooth LE,
using Blackmagic's published camera control protocol (the same commands ATEM uses for paint).

## Build
1. Install Android Studio (Koala or newer).
2. File → Open → select this folder. Let Gradle sync (it downloads Gradle 8.7 and dependencies).
3. Plug in your phone with USB debugging on and press Run.

## Camera setup
Camera: Menu → Setup → Bluetooth → On. In the app tap **Scan**, pick the camera, and enter the
6-digit PIN the camera shows when Android asks. After that it reconnects without a PIN.

## What's in it
- **Paint**: Lift / Gamma / Gain / Offset trackball wheels with master sliders, contrast + pivot,
  saturation, hue, luma mix, reset. 2x2 in portrait, 4-across in landscape/tablet.
- **Exposure**: ISO, shutter angle, white balance (Kelvin + tint, presets, Auto WB).
- **Lens**: iris (with f-number readout), focus, autofocus, auto iris, OIS.
- **REC** button in the top bar.
- Reads the camera's reports back so the controls stay in sync with changes made on the camera.

## Code map
- `protocol/CameraProtocol.kt` – packet encoder/decoder and all command builders (add more here)
- `protocol/CameraState.kt` – app state + parsing of camera reports
- `ble/CameraBleManager.kt` – scan, connect, pairing, notification subscription, write queue
- `ui/ColorWheel.kt` – trackball wheels and RGB mapping (`PaintControl` holds ranges and sensitivity)

## Tweaks
- Wheel sensitivity: `sensitivity` in `ColorWheel`, or `wheelScale` per control in `PaintControl`.
- Accent colour: `Accent` in `ui/Theme.kt`.
