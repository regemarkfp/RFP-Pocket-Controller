package com.regemarkfp.pocketcontrol.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.regemarkfp.pocketcontrol.CameraViewModel
import com.regemarkfp.pocketcontrol.protocol.CameraState

@Composable
fun LensScreen(state: CameraState, vm: CameraViewModel) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        SectionCard("Iris" + (state.fNumber?.let { " · f/%.1f".format(it) } ?: "")) {
            LabeledSlider(
                "Aperture", state.iris, 0f..1f,
                onChange = vm::setIris,
                scale = 100f, suffix = "%",
            )
            FilledTonalButton(onClick = vm::autoIris) { Text("Auto iris") }
        }

        SectionCard("Focus") {
            LabeledSlider(
                "Near ↔ Far", state.focus, 0f..1f,
                onChange = vm::setFocus,
                scale = 100f, suffix = "%",
            )
            FilledTonalButton(onClick = vm::autoFocus) { Text("Autofocus") }
        }

        SectionCard("Stabilisation") {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Optical image stabilisation")
                Switch(checked = state.stabilisation, onCheckedChange = vm::setStabilisation)
            }
        }

        Text(
            "Iris, focus and stabilisation only work with electronic MFT lenses " +
                "(and focus only on lenses that support autofocus control).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(8.dp),
        )
    }
}
