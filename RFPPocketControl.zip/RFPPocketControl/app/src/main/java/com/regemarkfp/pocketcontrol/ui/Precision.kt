package com.regemarkfp.pocketcontrol.ui

import androidx.compose.runtime.staticCompositionLocalOf

/**
 * Global precision mode.
 * drag         – slider movement per finger movement (1.0 = full track width moves the full range)
 * wheel        – trackball movement per finger movement
 * stepFraction – size of one +/− nudge as a fraction of the control's range
 * decimals     – digits shown in readouts
 */
enum class Precision(
    val label: String,
    val drag: Float,
    val wheel: Float,
    val stepFraction: Float,
    val decimals: Int,
) {
    COARSE("Coarse", 1.0f, 1.0f, 0.025f, 2),
    NORMAL("Normal", 0.5f, 0.5f, 0.005f, 2),
    FINE("Fine", 0.12f, 0.15f, 0.001f, 3),
}

val LocalPrecision = staticCompositionLocalOf { Precision.NORMAL }
