package com.regemarkfp.pocketcontrol.ble

import java.util.UUID

/** GATT UUIDs from Blackmagic's "Bluetooth LE camera control" documentation. */
object BmdUuids {
    val SERVICE: UUID = UUID.fromString("291D567A-6D75-11E6-8B77-86F30CA893D3")
    val OUTGOING_CONTROL: UUID = UUID.fromString("5DD3465F-1AEE-4299-8493-D2ECA2F8E1BB")
    val INCOMING_CONTROL: UUID = UUID.fromString("B864E140-76A0-416A-BF30-5876504537D9")
    val TIMECODE: UUID = UUID.fromString("6D8F2110-86F1-41BF-9AFB-451D87E976C8")
    val CAMERA_STATUS: UUID = UUID.fromString("7FE8691D-95DC-4FC5-8ABD-CA74B9F7D5FF")
    val DEVICE_NAME: UUID = UUID.fromString("FFAC0C52-C9FB-41A0-B063-CC76282EB89C")
    val PROTOCOL_VERSION: UUID = UUID.fromString("8F1FD018-B508-456F-8F82-3D392BEE2706")

    /** Standard Client Characteristic Configuration Descriptor. */
    val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
}
