package com.regemarkfp.pocketcontrol.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import androidx.core.content.ContextCompat
import com.regemarkfp.pocketcontrol.protocol.CameraCommand
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

sealed interface ConnectionState {
    data object Disconnected : ConnectionState
    data class Connecting(val name: String) : ConnectionState
    data class Pairing(val name: String) : ConnectionState
    data class Connected(val name: String) : ConnectionState
    data class Failed(val message: String) : ConnectionState
}

data class FoundDevice(
    val device: BluetoothDevice,
    val name: String,
    val rssi: Int,
    val isBlackmagic: Boolean,
)

/**
 * Scans for, pairs with and talks to a Blackmagic camera over Bluetooth LE.
 *
 * GATT allows one operation at a time, so every write goes through [awaitOp].
 * Commands are coalesced by parameter: while a slider is moving only the newest
 * value for that parameter is waiting, so the camera never falls behind your finger.
 */
@SuppressLint("MissingPermission") // Permissions are requested in MainActivity before any call.
class CameraBleManager(private val context: Context, private val scope: CoroutineScope) {

    private val adapter: BluetoothAdapter?
        get() = context.getSystemService(BluetoothManager::class.java)?.adapter

    val isBluetoothOn: Boolean get() = adapter?.isEnabled == true

    private val _devices = MutableStateFlow<List<FoundDevice>>(emptyList())
    val devices: StateFlow<List<FoundDevice>> = _devices.asStateFlow()

    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning.asStateFlow()

    private val _connection = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connection: StateFlow<ConnectionState> = _connection.asStateFlow()

    private val _incoming = MutableSharedFlow<ByteArray>(extraBufferCapacity = 256)
    /** Raw packets from the Incoming Camera Control characteristic. */
    val incoming: SharedFlow<ByteArray> = _incoming.asSharedFlow()

    private var gatt: BluetoothGatt? = null
    private var outgoing: BluetoothGattCharacteristic? = null
    private var incomingChar: BluetoothGattCharacteristic? = null
    private var deviceName = ""
    private var scanTimeout: Job? = null
    private var bondReceiverRegistered = false
    @Volatile private var ready = false
    @Volatile private var sessionStarting = false

    // ------------------------------------------------------------------ Scanning

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val record = result.scanRecord
            val advertisesService = record?.serviceUuids?.any { it.uuid == BmdUuids.SERVICE } == true
            val name = record?.deviceName ?: result.device.name
                ?: if (advertisesService) "Blackmagic camera" else return
            val isBmd = advertisesService ||
                listOf("pocket", "blackmagic", "bmpcc", "ursa").any { name.contains(it, ignoreCase = true) }
            val found = FoundDevice(result.device, name, result.rssi, isBmd)
            _devices.update { list ->
                (list.filterNot { it.device.address == found.device.address } + found)
                    .sortedWith(compareByDescending<FoundDevice> { it.isBlackmagic }.thenBy { it.name.lowercase() })
            }
        }

        override fun onScanFailed(errorCode: Int) {
            _scanning.value = false
            _connection.value = ConnectionState.Failed("Bluetooth scan failed (code $errorCode).")
        }
    }

    fun startScan() {
        val scanner = adapter?.bluetoothLeScanner
        if (scanner == null || !isBluetoothOn) {
            _connection.value = ConnectionState.Failed("Bluetooth is off on this phone.")
            return
        }
        if (_scanning.value) return
        if (_connection.value is ConnectionState.Failed) _connection.value = ConnectionState.Disconnected
        _devices.value = emptyList()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanner.startScan(null, settings, scanCallback)
        _scanning.value = true
        scanTimeout?.cancel()
        scanTimeout = scope.launch {
            delay(15_000)
            stopScan()
        }
    }

    fun stopScan() {
        scanTimeout?.cancel()
        if (_scanning.value) runCatching { adapter?.bluetoothLeScanner?.stopScan(scanCallback) }
        _scanning.value = false
    }

    // ---------------------------------------------------------------- Connection

    fun connect(found: FoundDevice) {
        stopScan()
        closeGatt()
        deviceName = found.name
        _connection.value = ConnectionState.Connecting(found.name)
        gatt = found.device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
    }

    fun disconnect() {
        closeGatt()
        _connection.value = ConnectionState.Disconnected
    }

    fun release() {
        stopScan()
        closeGatt()
    }

    private fun fail(message: String) {
        closeGatt()
        _connection.value = ConnectionState.Failed(message)
    }

    private fun closeGatt() {
        ready = false
        sessionStarting = false
        synchronized(pending) { pending.clear() }
        unregisterBondReceiver()
        gatt?.let {
            runCatching { it.disconnect() }
            runCatching { it.close() }
        }
        gatt = null
        outgoing = null
        incomingChar = null
        pendingOp?.complete(STATUS_CANCELLED)
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> scope.launch {
                    delay(300) // gives a bonded link time to settle before discovery
                    g.discoverServices()
                }
                BluetoothProfile.STATE_DISCONNECTED -> scope.launch {
                    if (g != gatt) return@launch
                    if (status == BluetoothGatt.GATT_SUCCESS) disconnect()
                    else fail("Lost connection to the camera (status $status). Check that Bluetooth is on in the camera's Setup menu and you're within range.")
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            scope.launch {
                val service = g.getService(BmdUuids.SERVICE)
                if (status != BluetoothGatt.GATT_SUCCESS || service == null) {
                    fail("That device isn't a Blackmagic camera (camera control service not found).")
                    return@launch
                }
                outgoing = service.getCharacteristic(BmdUuids.OUTGOING_CONTROL)
                incomingChar = service.getCharacteristic(BmdUuids.INCOMING_CONTROL)
                if (outgoing == null) {
                    fail("Camera control characteristic not found. Try updating the camera firmware.")
                    return@launch
                }
                val device = g.device
                if (device.bondState == BluetoothDevice.BOND_BONDED) {
                    startSession()
                } else {
                    _connection.value = ConnectionState.Pairing(deviceName)
                    registerBondReceiver()
                    if (device.bondState != BluetoothDevice.BOND_BONDING) device.createBond()
                }
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            pendingOp?.complete(status)
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            pendingOp?.complete(status)
        }

        // Android 13+
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            if (c.uuid == BmdUuids.INCOMING_CONTROL) _incoming.tryEmit(value)
        }

        // Android 12 and lower
        @Deprecated("Deprecated in API 33")
        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            if (Build.VERSION.SDK_INT >= 33) return
            val value = c.value ?: return
            if (c.uuid == BmdUuids.INCOMING_CONTROL) _incoming.tryEmit(value.copyOf())
        }
    }

    /** Subscribes to the camera's parameter reports, then opens the command queue. */
    private fun startSession() {
        if (ready || sessionStarting) return
        sessionStarting = true
        scope.launch {
            val g = gatt ?: return@launch
            val inc = incomingChar
            if (inc != null) {
                g.setCharacteristicNotification(inc, true)
                val cccd = inc.getDescriptor(BmdUuids.CCCD)
                if (cccd != null) {
                    val value = if (inc.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0)
                        BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                    else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    awaitOp { writeDescriptor(g, cccd, value) }
                }
            }
            if (gatt !== g) return@launch
            sessionStarting = false
            ready = true
            _connection.value = ConnectionState.Connected(deviceName)
            wake.trySend(Unit)
        }
    }

    // ------------------------------------------------------------------- Pairing

    private val bondReceiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(ctx: Context, intent: Intent) {
            val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
            } else {
                intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
            }
            if (device == null || device.address != gatt?.device?.address) return
            val state = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.BOND_NONE)
            val previous = intent.getIntExtra(BluetoothDevice.EXTRA_PREVIOUS_BOND_STATE, BluetoothDevice.BOND_NONE)
            when {
                state == BluetoothDevice.BOND_BONDED -> {
                    unregisterBondReceiver()
                    startSession()
                }
                state == BluetoothDevice.BOND_NONE && previous == BluetoothDevice.BOND_BONDING ->
                    fail("Pairing failed or was cancelled. Enter the 6-digit PIN shown on the camera's screen and try again.")
            }
        }
    }

    private fun registerBondReceiver() {
        if (bondReceiverRegistered) return
        ContextCompat.registerReceiver(
            context, bondReceiver,
            IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED),
            ContextCompat.RECEIVER_EXPORTED,
        )
        bondReceiverRegistered = true
    }

    private fun unregisterBondReceiver() {
        if (!bondReceiverRegistered) return
        runCatching { context.unregisterReceiver(bondReceiver) }
        bondReceiverRegistered = false
    }

    // -------------------------------------------------------------- Write queue

    private val opMutex = Mutex()
    @Volatile private var pendingOp: CompletableDeferred<Int>? = null

    /** Runs one GATT operation and waits for its callback (or a timeout). */
    private suspend fun awaitOp(start: () -> Boolean): Int = opMutex.withLock {
        val done = CompletableDeferred<Int>()
        pendingOp = done
        val started = try { start() } catch (e: SecurityException) { false }
        val result = if (!started) STATUS_NOT_STARTED
        else withTimeoutOrNull(OP_TIMEOUT_MS) { done.await() } ?: STATUS_TIMEOUT
        pendingOp = null
        result
    }

    private val pending = LinkedHashMap<Int, ByteArray>()
    private val wake = Channel<Unit>(Channel.CONFLATED)

    /** Queues a command. A newer command for the same parameter replaces an unsent older one. */
    fun send(command: CameraCommand) {
        if (!ready) return
        synchronized(pending) {
            pending.remove(command.key)
            pending[command.key] = command.toBytes()
        }
        wake.trySend(Unit)
    }

    init {
        scope.launch {
            for (signal in wake) {
                while (ready) {
                    val next = synchronized(pending) {
                        val iter = pending.entries.iterator()
                        if (iter.hasNext()) {
                            val entry = iter.next()
                            iter.remove()
                            entry.value
                        } else null
                    } ?: break
                    val g = gatt ?: break
                    val c = outgoing ?: break
                    awaitOp { writeCharacteristic(g, c, next) }
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun writeCharacteristic(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray): Boolean {
        val type = if (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0)
            BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        return if (Build.VERSION.SDK_INT >= 33) {
            g.writeCharacteristic(c, value, type) == BluetoothStatusCodes.SUCCESS
        } else {
            c.writeType = type
            c.setValue(value)
            g.writeCharacteristic(c)
        }
    }

    @Suppress("DEPRECATION")
    private fun writeDescriptor(g: BluetoothGatt, d: BluetoothGattDescriptor, value: ByteArray): Boolean =
        if (Build.VERSION.SDK_INT >= 33) {
            g.writeDescriptor(d, value) == BluetoothStatusCodes.SUCCESS
        } else {
            d.setValue(value)
            g.writeDescriptor(d)
        }

    private companion object {
        const val OP_TIMEOUT_MS = 2_000L
        const val STATUS_NOT_STARTED = -1
        const val STATUS_TIMEOUT = -2
        const val STATUS_CANCELLED = -3
    }
}
