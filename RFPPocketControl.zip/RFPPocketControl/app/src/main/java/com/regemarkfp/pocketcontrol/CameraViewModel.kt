package com.regemarkfp.pocketcontrol

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.regemarkfp.pocketcontrol.ble.CameraBleManager
import com.regemarkfp.pocketcontrol.ble.FoundDevice
import com.regemarkfp.pocketcontrol.protocol.CameraCommand
import com.regemarkfp.pocketcontrol.protocol.CameraState
import com.regemarkfp.pocketcontrol.protocol.Commands
import com.regemarkfp.pocketcontrol.protocol.IncomingParameter
import com.regemarkfp.pocketcontrol.protocol.Rgby
import com.regemarkfp.pocketcontrol.ui.PaintControl
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class CameraViewModel(app: Application) : AndroidViewModel(app) {

    private val ble = CameraBleManager(app, viewModelScope)

    val connection = ble.connection
    val devices = ble.devices
    val scanning = ble.scanning
    val isBluetoothOn: Boolean get() = ble.isBluetoothOn

    private val _state = MutableStateFlow(CameraState())
    val state: StateFlow<CameraState> = _state.asStateFlow()

    /** When we last sent each parameter, so the camera's echo doesn't fight a moving slider. */
    private val lastSent = HashMap<Int, Long>()

    init {
        viewModelScope.launch {
            ble.incoming.collect { packet ->
                val p = IncomingParameter.parse(packet) ?: return@collect
                val sentAt = lastSent[p.key] ?: 0L
                if (SystemClock.elapsedRealtime() - sentAt < ECHO_GUARD_MS) return@collect
                _state.update { it.applyIncoming(p) }
            }
        }
    }

    fun startScan() = ble.startScan()
    fun connect(device: FoundDevice) = ble.connect(device)
    fun disconnect() = ble.disconnect()

    private fun send(command: CameraCommand, guardEcho: Boolean = true) {
        if (guardEcho) lastSent[command.key] = SystemClock.elapsedRealtime()
        ble.send(command)
    }

    // ---------------------------------------------------------------- Paint
    fun setPaint(control: PaintControl, value: Rgby) {
        _state.update {
            when (control) {
                PaintControl.LIFT -> it.copy(lift = value)
                PaintControl.GAMMA -> it.copy(gamma = value)
                PaintControl.GAIN -> it.copy(gain = value)
                PaintControl.OFFSET -> it.copy(offset = value)
            }
        }
        send(
            when (control) {
                PaintControl.LIFT -> Commands.lift(value)
                PaintControl.GAMMA -> Commands.gamma(value)
                PaintControl.GAIN -> Commands.gain(value)
                PaintControl.OFFSET -> Commands.offset(value)
            }
        )
    }

    fun setContrast(pivot: Float, adjust: Float) {
        _state.update { it.copy(contrastPivot = pivot, contrastAdjust = adjust) }
        send(Commands.contrast(pivot, adjust))
    }

    fun setHueSaturation(hue: Float, saturation: Float) {
        _state.update { it.copy(hue = hue, saturation = saturation) }
        send(Commands.hueSaturation(hue, saturation))
    }

    fun setLumaMix(value: Float) {
        _state.update { it.copy(lumaMix = value) }
        send(Commands.lumaMix(value))
    }

    fun resetPaint() {
        _state.update { it.withPaintDefaults() }
        send(Commands.resetColourCorrection(), guardEcho = false)
    }

    // ------------------------------------------------------------- Exposure
    fun setIso(iso: Int) {
        _state.update { it.copy(iso = iso) }
        send(Commands.iso(iso))
    }

    fun setShutterAngle(degrees: Float) {
        _state.update { it.copy(shutterAngle = degrees) }
        send(Commands.shutterAngle(degrees))
    }

    fun setWhiteBalance(kelvin: Int, tint: Int) {
        _state.update { it.copy(whiteBalance = kelvin, tint = tint) }
        send(Commands.whiteBalance(kelvin, tint))
    }

    fun autoWhiteBalance() = send(Commands.autoWhiteBalance(), guardEcho = false)

    // ----------------------------------------------------------------- Lens
    fun setFocus(value: Float) {
        _state.update { it.copy(focus = value) }
        send(Commands.focus(value))
    }

    fun autoFocus() = send(Commands.autoFocus(), guardEcho = false)

    fun setIris(value: Float) {
        _state.update { it.copy(iris = value) }
        send(Commands.irisNormalised(value))
    }

    fun autoIris() = send(Commands.autoIris(), guardEcho = false)

    fun setStabilisation(on: Boolean) {
        _state.update { it.copy(stabilisation = on) }
        send(Commands.stabilisation(on))
    }

    // ------------------------------------------------------------- Transport
    fun toggleRecord() {
        val current = _state.value
        val mode = if (current.isRecording) 0 else 2
        _state.update { it.copy(transport = listOf(mode) + it.transport.drop(1)) }
        // No echo guard: if recording fails (no card, card full) the camera's report corrects the button.
        send(Commands.transport(mode, current.transport), guardEcho = false)
    }

    override fun onCleared() {
        ble.release()
    }

    private companion object {
        const val ECHO_GUARD_MS = 500L
    }
}
