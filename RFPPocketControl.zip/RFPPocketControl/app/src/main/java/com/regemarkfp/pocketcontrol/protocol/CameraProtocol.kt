package com.regemarkfp.pocketcontrol.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

/*
 * Blackmagic camera control protocol. The same packet format is used for SDI camera
 * control (ATEM) and the Bluetooth LE "Outgoing/Incoming Camera Control" characteristics.
 *
 *   [dest][length][commandId=0][reserved]  [category][parameter][dataType][operation]  [data...]
 *
 * length = 4 + data bytes. The whole packet is zero-padded to a multiple of 4 bytes.
 * All multi-byte values are little-endian. fixed16 = signed 5.11 fixed point (value * 2048).
 */

object DataType {
    const val VOID = 0      // also used for booleans (1 data byte)
    const val INT8 = 1
    const val INT16 = 2
    const val INT32 = 3
    const val INT64 = 4
    const val STRING = 5
    const val FIXED16 = 128
}

object Operation {
    const val ASSIGN = 0
    const val OFFSET = 1
}

class CameraCommand(
    val category: Int,
    val parameter: Int,
    val dataType: Int,
    val data: ByteArray = ByteArray(0),
    val operation: Int = Operation.ASSIGN,
    val destination: Int = 255,
) {
    /** Commands with the same key replace each other in the send queue. */
    val key: Int get() = (category shl 8) or parameter

    fun toBytes(): ByteArray {
        val commandLength = 4 + data.size
        val total = (4 + commandLength + 3) / 4 * 4
        val out = ByteArray(total)
        out[0] = destination.toByte()
        out[1] = commandLength.toByte()
        out[2] = 0 // command id 0 = change configuration
        out[3] = 0
        out[4] = category.toByte()
        out[5] = parameter.toByte()
        out[6] = dataType.toByte()
        out[7] = operation.toByte()
        data.copyInto(out, 8)
        return out
    }
}

internal fun fixed16Bytes(vararg values: Float): ByteArray {
    val buf = ByteBuffer.allocate(values.size * 2).order(ByteOrder.LITTLE_ENDIAN)
    for (v in values) {
        val raw = (v * 2048f).roundToInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
        buf.putShort(raw.toShort())
    }
    return buf.array()
}

internal fun int16Bytes(vararg values: Int): ByteArray {
    val buf = ByteBuffer.allocate(values.size * 2).order(ByteOrder.LITTLE_ENDIAN)
    for (v in values) buf.putShort(v.toShort())
    return buf.array()
}

internal fun int32Bytes(vararg values: Int): ByteArray {
    val buf = ByteBuffer.allocate(values.size * 4).order(ByteOrder.LITTLE_ENDIAN)
    for (v in values) buf.putInt(v)
    return buf.array()
}

internal fun int8Bytes(vararg values: Int): ByteArray = ByteArray(values.size) { values[it].toByte() }

/** Builders for the commands this app uses. Parameter numbers follow Blackmagic's spec. */
object Commands {
    // ---- Category 0: Lens ----
    fun focus(normalised: Float) =
        CameraCommand(0, 0, DataType.FIXED16, fixed16Bytes(normalised.coerceIn(0f, 1f)))

    fun autoFocus() = CameraCommand(0, 1, DataType.VOID)

    fun irisNormalised(normalised: Float) =
        CameraCommand(0, 3, DataType.FIXED16, fixed16Bytes(normalised.coerceIn(0f, 1f)))

    fun autoIris() = CameraCommand(0, 5, DataType.VOID)

    fun stabilisation(on: Boolean) =
        CameraCommand(0, 6, DataType.VOID, int8Bytes(if (on) 1 else 0))

    // ---- Category 1: Video ----
    fun whiteBalance(kelvin: Int, tint: Int) =
        CameraCommand(1, 2, DataType.INT16, int16Bytes(kelvin.coerceIn(2500, 10000), tint.coerceIn(-50, 50)))

    fun autoWhiteBalance() = CameraCommand(1, 3, DataType.VOID)

    /** Shutter angle in degrees (sent as degrees x 100). */
    fun shutterAngle(degrees: Float) =
        CameraCommand(1, 11, DataType.INT32, int32Bytes((degrees * 100f).roundToInt().coerceIn(100, 36000)))

    fun iso(value: Int) = CameraCommand(1, 14, DataType.INT32, int32Bytes(value))

    // ---- Category 8: Colour correction (paint) ----
    fun lift(c: Rgby) = CameraCommand(8, 0, DataType.FIXED16, fixed16Bytes(c.r, c.g, c.b, c.y))
    fun gamma(c: Rgby) = CameraCommand(8, 1, DataType.FIXED16, fixed16Bytes(c.r, c.g, c.b, c.y))
    fun gain(c: Rgby) = CameraCommand(8, 2, DataType.FIXED16, fixed16Bytes(c.r, c.g, c.b, c.y))
    fun offset(c: Rgby) = CameraCommand(8, 3, DataType.FIXED16, fixed16Bytes(c.r, c.g, c.b, c.y))

    fun contrast(pivot: Float, adjust: Float) =
        CameraCommand(8, 4, DataType.FIXED16, fixed16Bytes(pivot.coerceIn(0f, 1f), adjust.coerceIn(0f, 2f)))

    fun lumaMix(value: Float) = CameraCommand(8, 5, DataType.FIXED16, fixed16Bytes(value.coerceIn(0f, 1f)))

    fun hueSaturation(hue: Float, saturation: Float) =
        CameraCommand(8, 6, DataType.FIXED16, fixed16Bytes(hue.coerceIn(-1f, 1f), saturation.coerceIn(0f, 2f)))

    fun resetColourCorrection() = CameraCommand(8, 7, DataType.VOID)

    // ---- Category 10: Media / transport ----
    /** mode: 0 = preview, 1 = play, 2 = record. Other bytes are echoed from the camera's last report. */
    fun transport(mode: Int, current: List<Int>): CameraCommand {
        val c = (current + List(5) { 0 }).take(5)
        return CameraCommand(10, 1, DataType.INT8, int8Bytes(mode, c[1], c[2], c[3], c[4]))
    }
}

/** A parameter update sent by the camera on the Incoming Camera Control characteristic. */
class IncomingParameter(
    val category: Int,
    val parameter: Int,
    val dataType: Int,
    private val data: ByteArray,
) {
    val key: Int get() = (category shl 8) or parameter
    private fun buf() = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)

    fun fixed16(): List<Float> = List(data.size / 2) { buf().getShort(it * 2) / 2048f }
    fun int8(): List<Int> = data.map { it.toInt() }
    fun int16(): List<Int> = List(data.size / 2) { buf().getShort(it * 2).toInt() }
    fun int32(): List<Int> = List(data.size / 4) { buf().getInt(it * 4) }

    companion object {
        fun parse(packet: ByteArray): IncomingParameter? {
            if (packet.size < 8) return null
            val length = packet[1].toInt() and 0xFF
            if (length < 4 || 4 + length > packet.size) return null
            if (packet[2].toInt() != 0) return null
            return IncomingParameter(
                category = packet[4].toInt() and 0xFF,
                parameter = packet[5].toInt() and 0xFF,
                dataType = packet[6].toInt() and 0xFF,
                data = packet.copyOfRange(8, 4 + length),
            )
        }
    }
}
