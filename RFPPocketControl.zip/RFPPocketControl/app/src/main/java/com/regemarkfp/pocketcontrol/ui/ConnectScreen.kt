package com.regemarkfp.pocketcontrol.ui

import android.bluetooth.BluetoothAdapter
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.regemarkfp.pocketcontrol.CameraViewModel
import com.regemarkfp.pocketcontrol.ble.ConnectionState
import com.regemarkfp.pocketcontrol.ble.FoundDevice

@Composable
fun ConnectScreen(vm: CameraViewModel, connection: ConnectionState) {
    val devices by vm.devices.collectAsState()
    val scanning by vm.scanning.collectAsState()
    val enableBluetooth = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { if (vm.isBluetoothOn) vm.startScan() }
    val busy = connection is ConnectionState.Connecting || connection is ConnectionState.Pairing

    Column(
        Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(20.dp)
    ) {
        Text("RFP", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        Text("Pocket Control", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            "Control and paint a Blackmagic Pocket 4K over Bluetooth",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(20.dp))

        StatusBanner(connection)

        Button(
            onClick = {
                if (vm.isBluetoothOn) vm.startScan()
                else enableBluetooth.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            },
            enabled = !scanning && !busy,
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (scanning) "Scanning…" else "Scan for cameras") }

        if (scanning) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))

        Spacer(Modifier.height(12.dp))

        if (devices.isEmpty() && !scanning) {
            Text(
                "On the camera: Menu → Setup → Bluetooth → On. Then tap Scan. " +
                    "The first time you connect, Android asks for the 6-digit PIN shown on the camera's screen.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(devices, key = { it.device.address }) { d ->
                DeviceRow(d, enabled = !busy) { vm.connect(d) }
            }
        }
    }
}

@Composable
private fun StatusBanner(connection: ConnectionState) {
    val (text, isError) = when (connection) {
        is ConnectionState.Connecting -> "Connecting to ${connection.name}…" to false
        is ConnectionState.Pairing ->
            "Pairing with ${connection.name}. Enter the 6-digit PIN shown on the camera when Android asks." to false
        is ConnectionState.Failed -> connection.message to true
        else -> return
    }
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isError) MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
            else MaterialTheme.colorScheme.surfaceContainer
        ),
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(text, color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
            if (!isError) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 10.dp))
        }
    }
}

@Composable
private fun DeviceRow(d: FoundDevice, enabled: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(enabled = enabled, onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(d.name, style = MaterialTheme.typography.titleMedium)
                Text(
                    d.device.address + "  ·  ${d.rssi} dBm",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (d.isBlackmagic) {
                Text("CAMERA", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
fun PermissionScreen(onRequest: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Bluetooth access needed", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text(
            "Pocket Control uses Bluetooth to find and control your camera. It doesn't use your location.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = onRequest, modifier = Modifier.fillMaxWidth()) { Text("Allow Bluetooth") }
    }
}
