package com.regemarkfp.pocketcontrol.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

@Composable
fun SectionCard(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth().padding(vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(
                title.uppercase(),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.5.sp,
            )
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

/**
 * Slider row with − / + nudge buttons (hold to repeat), tap-to-type value and a reset.
 * Values are shown and typed in display units: value x [scale] + [suffix].
 */
@Composable
fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    default: Float? = null,
    nudgeSteps: List<Float>? = null, // coarse, normal, fine (in raw units)
    decimals: Int? = null,
    scale: Float = 1f,
    suffix: String = "",
) {
    val precision = LocalPrecision.current
    val span = range.endInclusive - range.start
    val step = nudgeSteps?.getOrNull(precision.ordinal) ?: (span * precision.stepFraction)
    val dec = decimals ?: max(0, precision.decimals - log10(scale).toInt())
    var editing by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            NudgeButton("−") { onChange((value - step).coerceIn(range)) }
            Text(
                formatNumber(value * scale, dec) + suffix,
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .width(78.dp)
                    .clip(MaterialTheme.shapes.small)
                    .clickable { editing = true }
                    .padding(vertical = 6.dp),
            )
            NudgeButton("+") { onChange((value + step).coerceIn(range)) }
            if (default != null) {
                Spacer(Modifier.width(4.dp))
                SmallButton("↺", enabled = abs(value - default) > 0.00001f) { onChange(default) }
            }
        }
        PrecisionSlider(value, range, onChange, default = default)
    }

    if (editing) {
        NumberEntryDialog(
            title = label,
            initial = value * scale,
            decimals = dec,
            min = range.start * scale,
            max = range.endInclusive * scale,
            suffix = suffix,
            onDismiss = { editing = false },
            onConfirm = { onChange((it / scale).coerceIn(range)) },
        )
    }
}

/**
 * Slider that moves relative to your finger (it never jumps to where you touch), scaled by
 * the current [Precision]. Double-tap returns to [default].
 */
@Composable
fun PrecisionSlider(
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    default: Float? = null,
) {
    val precision = LocalPrecision.current
    val latestOnChange by rememberUpdatedState(onChange)
    val latestPrecision by rememberUpdatedState(precision)
    val latestDefault by rememberUpdatedState(default)
    var local by remember { mutableFloatStateOf(value) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(value) { if (!dragging) local = value }

    val lo = range.start
    val hi = range.endInclusive
    val span = hi - lo
    val anchor = (default ?: lo).coerceIn(lo, hi)
    val primary = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.surfaceVariant
    val tick = MaterialTheme.colorScheme.onSurfaceVariant

    Canvas(
        modifier
            .fillMaxWidth()
            .height(40.dp)
            .pointerInput(lo, hi) {
                detectHorizontalDragGestures(
                    onDragStart = { dragging = true },
                    onDragEnd = { dragging = false },
                    onDragCancel = { dragging = false },
                ) { change, dx ->
                    change.consume()
                    local = (local + dx / size.width * span * latestPrecision.drag).coerceIn(lo, hi)
                    latestOnChange(local)
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = { latestDefault?.let { latestOnChange(it) } })
            }
    ) {
        val h = 6.dp.toPx()
        val cy = size.height / 2f
        val pad = 12.dp.toPx()
        val w = size.width - 2 * pad
        fun xOf(v: Float) = pad + (v - lo) / span * w
        drawRoundRect(track, Offset(pad, cy - h / 2), Size(w, h), CornerRadius(h / 2))
        val a = xOf(anchor)
        val b = xOf(local.coerceIn(lo, hi))
        drawRoundRect(primary, Offset(min(a, b), cy - h / 2), Size(abs(b - a), h), CornerRadius(h / 2))
        if (precision == Precision.FINE) {
            for (i in 0..20) {
                val x = pad + w * i / 20f
                val len = if (i % 5 == 0) 7.dp.toPx() else 3.dp.toPx()
                drawLine(tick.copy(alpha = 0.6f), Offset(x, cy + h), Offset(x, cy + h + len), 1.dp.toPx())
            }
        }
        drawCircle(primary, 10.dp.toPx(), Offset(b, cy))
        drawCircle(Color.Black.copy(alpha = 0.3f), 10.dp.toPx(), Offset(b, cy), style = Stroke(1.dp.toPx()))
    }
}

/** Round − / + button. Tap for one step, hold to repeat. */
@Composable
fun NudgeButton(label: String, onStep: () -> Unit) {
    val latest by rememberUpdatedState(onStep)
    val scope = rememberCoroutineScope()
    Box(
        Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    latest()
                    val repeat = scope.launch {
                        delay(400)
                        while (isActive) {
                            latest()
                            delay(60)
                        }
                    }
                    tryAwaitRelease()
                    repeat.cancel()
                })
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(label, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SmallButton(label: String, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier
            .size(34.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled, onClick = onClick)
            .alpha(if (enabled) 1f else 0.35f),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun NumberEntryDialog(
    title: String,
    initial: Float,
    decimals: Int,
    min: Float,
    max: Float,
    suffix: String = "",
    onDismiss: () -> Unit,
    onConfirm: (Float) -> Unit,
) {
    var text by remember { mutableStateOf(String.format(Locale.US, "%.${decimals}f", initial)) }
    val parsed = text.replace(',', '.').trim().toFloatOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                isError = parsed == null,
                suffix = { if (suffix.isNotEmpty()) Text(suffix) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                supportingText = { Text("Range ${formatNumber(min, decimals)} to ${formatNumber(max, decimals)}") },
            )
        },
        confirmButton = {
            TextButton(
                enabled = parsed != null,
                onClick = {
                    parsed?.let { onConfirm(it.coerceIn(min, max)) }
                    onDismiss()
                },
            ) { Text("Set") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

fun formatNumber(v: Float, decimals: Int): String =
    if (decimals <= 0) v.roundToInt().toString() else "%.${decimals}f".format(v)
