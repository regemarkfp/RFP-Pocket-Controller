package com.regemarkfp.pocketcontrol.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Accent = Color(0xFFF2A93B)      // warm amber, change to match your RFP branding
val RecordRed = Color(0xFFE5352B)

private val Scheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF1A1205),
    secondary = Color(0xFF8FB8FF),
    background = Color(0xFF0E0F11),
    onBackground = Color(0xFFECEDEF),
    surface = Color(0xFF15171A),
    onSurface = Color(0xFFECEDEF),
    surfaceVariant = Color(0xFF23262B),
    onSurfaceVariant = Color(0xFF9AA0A8),
    surfaceContainer = Color(0xFF1B1E22),
    error = Color(0xFFFF6B61),
)

@Composable
fun PocketControlTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
