package com.regemarkfp.pocketcontrol.ui

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.regemarkfp.pocketcontrol.CameraViewModel
import com.regemarkfp.pocketcontrol.protocol.CameraState
import com.regemarkfp.pocketcontrol.protocol.Rgby

fun CameraState.valueFor(control: PaintControl): Rgby = when (control) {
    PaintControl.LIFT -> lift
    PaintControl.GAMMA -> gamma
    PaintControl.GAIN -> gain
    PaintControl.OFFSET -> offset
}

@Composable
fun PaintScreen(state: CameraState, vm: CameraViewModel) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        // Phone portrait: 2 x 2 wheels. Landscape / tablet: all four in a row like ATEM.
        val columns = if (maxWidth > 700.dp) 4 else 2
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 8.dp)
        ) {
            PaintControl.entries.chunked(columns).forEach { row ->
                Row(Modifier.fillMaxWidth()) {
                    row.forEach { ctl ->
                        WheelPanel(
                            control = ctl,
                            value = state.valueFor(ctl),
                            onChange = { vm.setPaint(ctl, it) },
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }
            Text(
                "Drag a wheel to balance colour; the bar below it is master level. Tap ± on a wheel for exact R/G/B/Y nudges, tap any number to type it. Double-tap a wheel or bar to reset it.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(8.dp),
            )
            Column(Modifier.padding(horizontal = 4.dp)) {
                SectionCard("Contrast & colour") {
                    LabeledSlider("Contrast", state.contrastAdjust, 0f..2f,
                        onChange = { vm.setContrast(state.contrastPivot, it) }, default = 1f)
                    LabeledSlider("Pivot", state.contrastPivot, 0f..1f,
                        onChange = { vm.setContrast(it, state.contrastAdjust) }, default = 0.5f)
                    LabeledSlider("Saturation", state.saturation, 0f..2f,
                        onChange = { vm.setHueSaturation(state.hue, it) }, default = 1f)
                    LabeledSlider("Hue", state.hue, -1f..1f,
                        onChange = { vm.setHueSaturation(it, state.saturation) }, default = 0f,
                        scale = 180f, suffix = "°")
                    LabeledSlider("Luma mix", state.lumaMix, 0f..1f,
                        onChange = { vm.setLumaMix(it) }, default = 1f,
                        scale = 100f, suffix = "%")
                }
                Spacer(Modifier.height(4.dp))
                OutlinedButton(onClick = vm::resetPaint, modifier = Modifier.fillMaxWidth()) {
                    Text("Reset all colour correction")
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}
