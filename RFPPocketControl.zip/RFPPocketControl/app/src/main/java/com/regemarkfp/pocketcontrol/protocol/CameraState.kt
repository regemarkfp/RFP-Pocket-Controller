package com.regemarkfp.pocketcontrol.protocol

import kotlin.math.pow
import kotlin.math.sqrt

data class Rgby(val r: Float, val g: Float, val b: Float, val y: Float) {
    companion object {
        fun all(v: Float) = Rgby(v, v, v, v)
    }
}

/** Everything the app shows. Updated optimistically by the UI and corrected by the camera's reports. */
data class CameraState(
    // Paint
    val lift: Rgby = Rgby.all(0f),
    val gamma: Rgby = Rgby.all(0f),
    val gain: Rgby = Rgby.all(1f),
    val offset: Rgby = Rgby.all(0f),
    val contrastPivot: Float = 0.5f,
    val contrastAdjust: Float = 1f,
    val lumaMix: Float = 1f,
    val hue: Float = 0f,
    val saturation: Float = 1f,
    // Lens
    val focus: Float = 0.5f,
    val iris: Float = 0.5f,
    val fNumber: Float? = null,
    val stabilisation: Boolean = false,
    // Video
    val whiteBalance: Int = 5600,
    val tint: Int = 0,
    val iso: Int = 400,
    val shutterAngle: Float = 180f,
    // Media
    val transport: List<Int> = listOf(0, 0, 0, 0, 0),
) {
    val isRecording: Boolean get() = transport.firstOrNull() == 2

    fun applyIncoming(p: IncomingParameter): CameraState = when (p.category to p.parameter) {
        0 to 0 -> p.fixed16().firstOrNull()?.let { copy(focus = it) }
        // 0.2 = aperture value (AV); f-number = sqrt(2^AV)
        0 to 2 -> p.fixed16().firstOrNull()?.let { copy(fNumber = sqrt(2.0.pow(it.toDouble())).toFloat()) }
        0 to 3 -> p.fixed16().firstOrNull()?.let { copy(iris = it) }
        0 to 6 -> p.int8().firstOrNull()?.let { copy(stabilisation = it != 0) }
        1 to 2 -> p.int16().takeIf { it.size >= 2 }?.let { copy(whiteBalance = it[0], tint = it[1]) }
        1 to 11 -> p.int32().firstOrNull()?.let { copy(shutterAngle = it / 100f) }
        1 to 14 -> p.int32().firstOrNull()?.let { copy(iso = it) }
        8 to 0 -> p.rgby()?.let { copy(lift = it) }
        8 to 1 -> p.rgby()?.let { copy(gamma = it) }
        8 to 2 -> p.rgby()?.let { copy(gain = it) }
        8 to 3 -> p.rgby()?.let { copy(offset = it) }
        8 to 4 -> p.fixed16().takeIf { it.size >= 2 }?.let { copy(contrastPivot = it[0], contrastAdjust = it[1]) }
        8 to 5 -> p.fixed16().firstOrNull()?.let { copy(lumaMix = it) }
        8 to 6 -> p.fixed16().takeIf { it.size >= 2 }?.let { copy(hue = it[0], saturation = it[1]) }
        10 to 1 -> p.int8().takeIf { it.size >= 5 }?.let { copy(transport = it.take(5)) }
        else -> null
    } ?: this

    fun withPaintDefaults() = copy(
        lift = Rgby.all(0f), gamma = Rgby.all(0f), gain = Rgby.all(1f), offset = Rgby.all(0f),
        contrastPivot = 0.5f, contrastAdjust = 1f, lumaMix = 1f, hue = 0f, saturation = 1f,
    )
}

private fun IncomingParameter.rgby(): Rgby? =
    fixed16().takeIf { it.size >= 4 }?.let { Rgby(it[0], it[1], it[2], it[3]) }
