package com.regemarkfp.pocketcontrol.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.regemarkfp.pocketcontrol.CameraViewModel
import com.regemarkfp.pocketcontrol.protocol.CameraState
import kotlin.math.abs
import kotlin.math.roundToInt

private val IsoValues = listOf(100, 200, 400, 800, 1000, 1250, 1600, 2500, 3200, 6400, 12800, 25600)
private val ShutterAngles = listOf(45f, 90f, 144f, 172.8f, 180f, 270f, 360f)
private val WbPresets = listOf(3200, 4500, 5600, 6500)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ExposureScreen(state: CameraState, vm: CameraViewModel) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        SectionCard("ISO · ${state.iso}") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IsoValues.forEach { iso ->
                    FilterChip(
                        selected = state.iso == iso,
                        onClick = { vm.setIso(iso) },
                        label = { Text(iso.toString()) },
                    )
                }
            }
        }

        SectionCard("Shutter angle · ${formatAngle(state.shutterAngle)}") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ShutterAngles.forEach { angle ->
                    FilterChip(
                        selected = abs(state.shutterAngle - angle) < 0.5f,
                        onClick = { vm.setShutterAngle(angle) },
                        label = { Text(formatAngle(angle)) },
                    )
                }
            }
        }

        SectionCard("White balance") {
            LabeledSlider(
                "Colour temp", state.whiteBalance.toFloat(), 2500f..10000f,
                onChange = { vm.setWhiteBalance(((it / 50f).roundToInt() * 50), state.tint) },
                default = 5600f,
                format = { "${it.roundToInt()}K" },
            )
            LabeledSlider(
                "Tint", state.tint.toFloat(), -50f..50f,
                onChange = { vm.setWhiteBalance(state.whiteBalance, it.roundToInt()) },
                default = 0f,
                format = { "%+d".format(it.roundToInt()) },
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                WbPresets.forEach { k ->
                    FilterChip(
                        selected = state.whiteBalance == k,
                        onClick = { vm.setWhiteBalance(k, state.tint) },
                        label = { Text("${k}K") },
                    )
                }
                FilledTonalButton(onClick = vm::autoWhiteBalance) { Text("Auto WB") }
            }
        }
    }
}

private fun formatAngle(a: Float): String =
    if (abs(a - a.roundToInt()) < 0.05f) "${a.roundToInt()}°" else "%.1f°".format(a)
