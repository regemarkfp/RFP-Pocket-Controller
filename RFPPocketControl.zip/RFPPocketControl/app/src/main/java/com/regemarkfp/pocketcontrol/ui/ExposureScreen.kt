package com.regemarkfp.pocketcontrol.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.regemarkfp.pocketcontrol.CameraViewModel
import com.regemarkfp.pocketcontrol.protocol.CameraState
import kotlin.math.abs
import kotlin.math.roundToInt

/** Pocket 4K ISO steps in 1/3 stops. */
private val AllIso = listOf(
    100, 125, 160, 200, 250, 320, 400, 500, 640, 800, 1000, 1250, 1600,
    2000, 2500, 3200, 4000, 5000, 6400, 8000, 10000, 12800, 16000, 20000, 25600,
)
private val IsoChips = listOf(100, 200, 400, 800, 1250, 1600, 3200, 6400, 12800, 25600)
private val ShutterAngles = listOf(45f, 90f, 144f, 172.8f, 180f, 270f, 360f)
private val WbPresets = listOf(3200, 4500, 5600, 6500)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ExposureScreen(state: CameraState, vm: CameraViewModel) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        SectionCard("ISO") {
            // 1/3-stop stepper
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("1/3 stop", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                NudgeButton("−") { stepIso(state.iso, -1)?.let(vm::setIso) }
                Text(
                    "ISO ${state.iso}",
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
                NudgeButton("+") { stepIso(state.iso, 1)?.let(vm::setIso) }
            }
            Spacer(Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IsoChips.forEach { iso ->
                    FilterChip(
                        selected = state.iso == iso,
                        onClick = { vm.setIso(iso) },
                        label = { Text(iso.toString()) },
                    )
                }
            }
        }

        SectionCard("Shutter angle") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ShutterAngles.forEach { angle ->
                    FilterChip(
                        selected = abs(state.shutterAngle - angle) < 0.05f,
                        onClick = { vm.setShutterAngle(angle) },
                        label = { Text(formatAngle(angle)) },
                    )
                }
            }
            LabeledSlider(
                "Custom angle", state.shutterAngle, 11.2f..360f,
                onChange = vm::setShutterAngle,
                default = 180f,
                nudgeSteps = listOf(10f, 1f, 0.1f),
                decimals = 1,
                suffix = "°",
            )
        }

        SectionCard("White balance") {
            LabeledSlider(
                "Colour temp", state.whiteBalance.toFloat(), 2500f..10000f,
                onChange = { vm.setWhiteBalance(((it / 50f).roundToInt() * 50), state.tint) },
                default = 5600f,
                nudgeSteps = listOf(500f, 100f, 50f),
                decimals = 0,
                suffix = "K",
            )
            LabeledSlider(
                "Tint", state.tint.toFloat(), -50f..50f,
                onChange = { vm.setWhiteBalance(state.whiteBalance, it.roundToInt()) },
                default = 0f,
                nudgeSteps = listOf(5f, 1f, 1f),
                decimals = 0,
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                WbPresets.forEach { k ->
                    FilterChip(
                        selected = state.whiteBalance == k,
                        onClick = { vm.setWhiteBalance(k, state.tint) },
                        label = { Text("${k}K") },
                    )
                }
                FilledTonalButton(onClick = vm::autoWhiteBalance) { Text("Auto WB") }
            }
        }
    }
}

private fun stepIso(current: Int, direction: Int): Int? {
    val idx = AllIso.indexOfFirst { it >= current }.let { if (it < 0) AllIso.lastIndex else it }
    val base = if (direction > 0 && AllIso[idx] > current) idx - 1 else idx
    return AllIso.getOrNull(base + direction)
}

private fun formatAngle(a: Float): String =
    if (abs(a - a.roundToInt()) < 0.05f) "${a.roundToInt()}°" else "%.1f°".format(a)
