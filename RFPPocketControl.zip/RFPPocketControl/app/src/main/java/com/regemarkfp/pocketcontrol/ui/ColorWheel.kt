package com.regemarkfp.pocketcontrol.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.regemarkfp.pocketcontrol.protocol.Rgby
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * The four primary corrections, ATEM-style. [wheelScale] is how far R/G/B move when the
 * trackball is at the edge of the wheel; [yMin]/[yMax] is the master (luma) slider range.
 * The camera accepts wider ranges ([min]/[max]) than are practical on a phone slider.
 */
enum class PaintControl(
    val title: String,
    val neutral: Float,
    val wheelScale: Float,
    val yMin: Float,
    val yMax: Float,
    val min: Float,
    val max: Float,
) {
    LIFT("Lift", 0f, 0.25f, -1f, 1f, -2f, 2f),
    GAMMA("Gamma", 0f, 0.5f, -2f, 2f, -4f, 4f),
    GAIN("Gain", 1f, 0.5f, 0f, 4f, 0f, 15.99f),
    OFFSET("Offset", 0f, 0.5f, -2f, 2f, -8f, 8f),
}

/**
 * Maps a 2D trackball position to R/G/B offsets. Red, green and blue sit 120 degrees apart
 * (roughly where they are on a vectorscope), so pushing towards a colour adds it and
 * removes its complement without changing overall level.
 */
object WheelMath {
    private val angles = doubleArrayOf(103.0, 223.0, 343.0).map { Math.toRadians(it) }
    private val cosA = angles.map { cos(it).toFloat() }
    private val sinA = angles.map { sin(it).toFloat() }

    fun toWheel(c: Rgby, ctl: PaintControl): Offset {
        val d = floatArrayOf(c.r - ctl.neutral, c.g - ctl.neutral, c.b - ctl.neutral)
        var x = 0f
        var y = 0f
        for (i in 0..2) {
            x += d[i] * cosA[i]
            y += d[i] * sinA[i]
        }
        val k = 2f / 3f / ctl.wheelScale
        return clampToDisc(Offset(x * k, y * k))
    }

    fun fromWheel(pos: Offset, current: Rgby, ctl: PaintControl): Rgby {
        val common = (current.r + current.g + current.b) / 3f - ctl.neutral
        fun ch(i: Int) = (ctl.neutral + common + ctl.wheelScale * (pos.x * cosA[i] + pos.y * sinA[i]))
            .coerceIn(ctl.min, ctl.max)
        return current.copy(r = ch(0), g = ch(1), b = ch(2))
    }

    fun clampToDisc(o: Offset): Offset {
        val len = hypot(o.x, o.y)
        return if (len > 1f) Offset(o.x / len, o.y / len) else o
    }

    /** Colour shown at a screen angle (radians, clockwise from 3 o'clock). */
    fun colourAt(screenAngle: Float): Color {
        val a = -screenAngle // screen y points down, maths y points up
        fun ch(i: Int) = (0.5f + 0.5f * (cos(a) * cosA[i] + sin(a) * sinA[i])).coerceIn(0f, 1f)
        return Color(ch(0), ch(1), ch(2))
    }
}

@Composable
fun ColorWheel(
    position: Offset,
    onDrag: (Offset) -> Unit,
    onReset: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val latestOnDrag by rememberUpdatedState(onDrag)
    val latestOnReset by rememberUpdatedState(onReset)
    val precision = LocalPrecision.current
    val latestPrecision by rememberUpdatedState(precision)
    var local by remember { mutableStateOf(position) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(position) { if (!dragging) local = position }

    val sweep = remember { List(37) { i -> WheelMath.colourAt(Math.toRadians(i * 10.0).toFloat()) } }

    Canvas(
        modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { dragging = true },
                    onDragEnd = { dragging = false },
                    onDragCancel = { dragging = false },
                ) { change, drag ->
                    change.consume()
                    val radius = size.width / 2f
                    // Trackball feel: relative movement, scaled by the precision mode.
                    val k = latestPrecision.wheel
                    local = WheelMath.clampToDisc(
                        Offset(local.x + drag.x / radius * k, local.y - drag.y / radius * k)
                    )
                    latestOnDrag(local)
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = { latestOnReset() })
            }
    ) {
        val r = size.minDimension / 2f
        val c = center
        drawCircle(Brush.sweepGradient(sweep, c), r, c)
        drawCircle(Brush.radialGradient(listOf(Color(0xFF2B2D31), Color(0x002B2D31)), c, r), r, c)
        drawCircle(Color.Black.copy(alpha = 0.30f), r, c)
        val line = Color.White.copy(alpha = 0.18f)
        drawLine(line, Offset(c.x - r, c.y), Offset(c.x + r, c.y), 1.dp.toPx())
        drawLine(line, Offset(c.x, c.y - r), Offset(c.x, c.y + r), 1.dp.toPx())
        drawCircle(line, r * 0.5f, c, style = Stroke(1.dp.toPx()))
        if (precision == Precision.FINE) {
            drawCircle(line, r * 0.25f, c, style = Stroke(1.dp.toPx()))
            drawCircle(line, r * 0.1f, c, style = Stroke(1.dp.toPx()))
        }
        drawCircle(Color.White.copy(alpha = 0.35f), r, c, style = Stroke(1.5.dp.toPx()))
        val p = Offset(c.x + local.x * r, c.y - local.y * r)
        drawLine(Color.White.copy(alpha = 0.5f), c, p, 1.dp.toPx())
        drawCircle(Color.Black.copy(alpha = 0.5f), 10.dp.toPx(), p, style = Stroke(5.dp.toPx()))
        drawCircle(Color.White, 10.dp.toPx(), p, style = Stroke(2.5.dp.toPx()))
    }
}

private val ChannelColours = listOf(Color(0xFFFF6B6B), Color(0xFF6BE38A), Color(0xFF6BA8FF), Color(0xFFE6E6E6))

@Composable
fun WheelPanel(
    control: PaintControl,
    value: Rgby,
    onChange: (Rgby) -> Unit,
    modifier: Modifier = Modifier,
) {
    var expanded by rememberSaveable(control) { mutableStateOf(false) }
    val precision = LocalPrecision.current
    val step = (control.yMax - control.yMin) * precision.stepFraction
    val channels = listOf(value.r, value.g, value.b, value.y)
    fun withChannel(i: Int, v: Float): Rgby {
        val c = v.coerceIn(control.min, control.max)
        return when (i) {
            0 -> value.copy(r = c)
            1 -> value.copy(g = c)
            2 -> value.copy(b = c)
            else -> value.copy(y = c)
        }
    }

    Card(
        modifier = modifier.padding(4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    ) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(control.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                SmallButton(if (expanded) "▴" else "±") { expanded = !expanded }
                SmallButton("↺") { onChange(Rgby.all(control.neutral)) }
            }
            ColorWheel(
                position = WheelMath.toWheel(value, control),
                onDrag = { onChange(WheelMath.fromWheel(it, value, control)) },
                onReset = { onChange(value.copy(r = control.neutral, g = control.neutral, b = control.neutral)) },
            )
            PrecisionSlider(
                value = value.y,
                range = control.yMin..control.yMax,
                onChange = { onChange(value.copy(y = it)) },
                default = control.neutral,
            )
            if (!expanded) {
                Row(
                    Modifier.fillMaxWidth().clickable { expanded = true }.padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    channels.forEachIndexed { i, v -> Readout(v, ChannelColours[i], precision.decimals) }
                }
            } else {
                listOf("R", "G", "B", "Y").forEachIndexed { i, name ->
                    ChannelRow(
                        name = name,
                        colour = ChannelColours[i],
                        value = channels[i],
                        decimals = precision.decimals,
                        control = control,
                        onStep = { dir -> onChange(withChannel(i, channels[i] + dir * step)) },
                        onSet = { onChange(withChannel(i, it)) },
                    )
                }
            }
        }
    }
}

@Composable
private fun ChannelRow(
    name: String,
    colour: Color,
    value: Float,
    decimals: Int,
    control: PaintControl,
    onStep: (Int) -> Unit,
    onSet: (Float) -> Unit,
) {
    var editing by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(name, color = colour, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.width(16.dp))
        NudgeButton("−") { onStep(-1) }
        Text(
            formatNumber(value, decimals),
            color = colour,
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.weight(1f).clickable { editing = true }.padding(vertical = 6.dp),
        )
        NudgeButton("+") { onStep(1) }
    }
    if (editing) {
        NumberEntryDialog(
            title = "${control.title} $name",
            initial = value,
            decimals = 3,
            min = control.min,
            max = control.max,
            onDismiss = { editing = false },
            onConfirm = onSet,
        )
    }
}

@Composable
private fun Readout(v: Float, colour: Color, decimals: Int) {
    Text(formatNumber(v, decimals), color = colour, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
}
